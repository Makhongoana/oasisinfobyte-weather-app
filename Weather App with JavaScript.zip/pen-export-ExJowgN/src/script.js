javascript

async function getWeather() {

  const locationInput = document.getElementById("locationInput");

  const location = locationInput.value;

  if (!location) {

    alert("Johannesburg.");

    return;

  }

  const apiKey = "40d6037f02587cc5a5aebb4153bf3c6b"; // Replace with your own API key

  const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`);

  const data = await response.json();

  const weatherDescription = data.weather[0].description;

  const tempCelsius = data.main.temp - 273.15;

  const tempKelvin = data.main.temp;

  document.getElementById("weatherDescription").textContent = `Weather: ${weatherDescription}`;

  document.getElementById("tempCelsius").textContent = tempCelsius.toFixed(1);

  document.getElementById("tempKelvin").textContent = tempKelvin.toFixed(1);

}